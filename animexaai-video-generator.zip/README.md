# AnimexAAI - Starter repo (clean)

This is a minimal starter repo created for uploading from Colab.
Files:
- clean_anime_video_generator.ipynb : example notebook
- app/* : example app files (placeholders)
- README / package.json : config

You can edit or replace files as needed.
