export async function POST(request) {
  const body = await request.json().catch(()=>({}));
  return new Response(JSON.stringify({ status: 'ok', received: body }), {
    headers: { 'Content-Type': 'application/json' },
  });
}
