export default function RootLayout({ children }) {
  return (
    <html>
      <head>
        <title>AnimexAAI</title>
      </head>
      <body>
        {children}
      </body>
    </html>
  )
}
