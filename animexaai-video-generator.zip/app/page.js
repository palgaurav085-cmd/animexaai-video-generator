export default function Home() {
  return (
    <main>
      <h1>AnimexAAI - Starter</h1>
      <p>This is a placeholder app page. Replace with your UI.</p>
    </main>
  )
}
